package com.bajaj.bookstore.bookstoreREST.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bajaj.bookstore.bookstoreREST.entity.Book;

public interface bookRepository extends JpaRepository<Book,Integer>{

}
