package com.bajaj.bookstore.bookstoreREST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreRestApplication.class, args);
	}

}
