package com.bajaj.bookstore.bookstoreREST.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.bajaj.bookstore.bookstoreREST.entity.Book;
import com.bajaj.bookstore.bookstoreREST.service.bookService;


@RestController
public class bookController {
	
	@Autowired bookService service;
	
	@GetMapping("/books")
	public List<Book> getAllAccount(){
		return service.getBooks();
	}
	
	@RequestMapping(method=RequestMethod.GET,path="/books/{id}")
	public Book getBookDetails(@PathVariable("id")Integer id) {
		return service.getBook(id);
	}
	
	@PostMapping("/books")
	public Book insertBook(@RequestBody Book b) {
		return service.addBook(b);
	}
	
	@PutMapping("/books/{id}")
	public Book updateBook(@PathVariable("id")Integer id, @RequestBody Book b)
	{
		return service.editBook(b, id);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,path="/books/{id}")
	public String removeBook(@PathVariable("id")Integer id) {
		service.deleteBook(id);
		return "Book Details are removed Successfully.....";
	}
}
