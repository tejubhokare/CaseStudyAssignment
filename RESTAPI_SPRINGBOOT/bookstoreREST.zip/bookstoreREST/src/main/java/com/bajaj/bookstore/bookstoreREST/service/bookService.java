package com.bajaj.bookstore.bookstoreREST.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bajaj.bookstore.bookstoreREST.entity.Book;
import com.bajaj.bookstore.bookstoreREST.repository.bookRepository;

@Service
public class bookService {
	@Autowired bookRepository bookrepo;
	
	//Retrieve All Books information 
	public List<Book> getBooks(){
		return bookrepo.findAll();
	}
	
	//Retrieve a particular Book detail 
	public Book getBook(Integer id) {
		return bookrepo.findById(id).get();
	}
	
	//Add new book details
	public Book addBook(Book b) {
		return bookrepo.save(b);
	}
	
	//Edit an existing book details
	public Book editBook(Book b, Integer id) {
		return bookrepo.save(b);
	}
	
	//Delete a book details
	public void deleteBook(Integer id) {
		bookrepo.deleteById(id);
		
	}

	
	
}
