package com.bajaj.bookstore.bookstoreREST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
